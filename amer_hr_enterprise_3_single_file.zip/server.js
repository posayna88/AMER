
const express = require("express");
const cors = require("cors");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const multer = require("multer");
const { Pool } = require("pg");
const path = require("path");
require("dotenv").config();

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname,"public")));
app.use("/uploads",express.static(path.join(__dirname,"uploads")));

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl:{rejectUnauthorized:false}
});

const storage = multer.diskStorage({
  destination:"uploads/",
  filename:(req,file,cb)=>cb(null,Date.now()+"-"+file.originalname)
});
const upload = multer({storage});

async function init(){
  await pool.query(`CREATE TABLE IF NOT EXISTS users(
    id SERIAL PRIMARY KEY,
    name TEXT,
    email TEXT UNIQUE,
    password_hash TEXT,
    role TEXT
  )`);

  await pool.query(`CREATE TABLE IF NOT EXISTS employees(
    id SERIAL PRIMARY KEY,
    full_name TEXT,
    department TEXT,
    salary NUMERIC,
    profile_image TEXT
  )`);

  const existing = await pool.query("SELECT * FROM users WHERE role='super_admin'");
  if(existing.rows.length===0){
    const hash = await bcrypt.hash("Admin@123",10);
    await pool.query(
      "INSERT INTO users(name,email,password_hash,role) VALUES($1,$2,$3,$4)",
      ["Super Admin","admin@amerhr.com",hash,"super_admin"]
    );
  }
}
init();

function auth(req,res,next){
  const token=req.headers.authorization;
  if(!token) return res.sendStatus(401);
  try{
    req.user=jwt.verify(token,process.env.JWT_SECRET);
    next();
  }catch{res.sendStatus(403);}
}

app.post("/api/login",async(req,res)=>{
  const {email,password}=req.body;
  const user=await pool.query("SELECT * FROM users WHERE email=$1",[email]);
  if(!user.rows.length) return res.sendStatus(404);
  const valid=await bcrypt.compare(password,user.rows[0].password_hash);
  if(!valid) return res.sendStatus(401);
  const token=jwt.sign({id:user.rows[0].id,role:user.rows[0].role},
    process.env.JWT_SECRET,{expiresIn:"8h"});
  res.json({token});
});

app.get("/api/employees",auth,async(req,res)=>{
  const data=await pool.query("SELECT * FROM employees ORDER BY id DESC");
  res.json(data.rows);
});

app.post("/api/employees",auth,upload.single("image"),async(req,res)=>{
  const {full_name,department,salary}=req.body;
  const image=req.file?req.file.filename:null;
  await pool.query(
    "INSERT INTO employees(full_name,department,salary,profile_image) VALUES($1,$2,$3,$4)",
    [full_name,department,salary,image]
  );
  res.sendStatus(200);
});

app.get("*",(req,res)=>{
  res.sendFile(path.join(__dirname,"public/index.html"));
});

app.listen(process.env.PORT||5000);
